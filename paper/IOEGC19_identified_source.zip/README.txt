Identified editorial LaTeX source for the 19th IOE Graduate Conference, 2026.

This package includes the article source, author information, bibliography, supplied
conference class, page-number helper, and all graphics used by the manuscript.
The author names, affiliation, and email addresses are included in paperinfo.tex.

Compile from this directory with Tectonic using:

    tectonic article.tex
